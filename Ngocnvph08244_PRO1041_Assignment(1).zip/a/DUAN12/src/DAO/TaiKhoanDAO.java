/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.NhanVien;
import Entities.TaiKhoan;
import Hibernate.NewHibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Administrator
 */
public class TaiKhoanDAO {
   private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<TaiKhoan> layDanhSach() {
        List<TaiKhoan> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From TaiKhoan where isDelete='0'").list();
        session.close();

        return list;
    }

    public TaiKhoan find(String NhanVienID) {
        TaiKhoan entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (TaiKhoan) session.get(TaiKhoan.class, NhanVienID);
        session.close();

        return entity;
    }

    public boolean delete(TaiKhoan tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.delete(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean save(TaiKhoan tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }
    

    public boolean update(TaiKhoan tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.update(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }
}
