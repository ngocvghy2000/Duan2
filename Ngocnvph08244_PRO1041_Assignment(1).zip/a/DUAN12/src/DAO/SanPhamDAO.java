/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.LoaiSanPham;
import Entities.SanPham;
import Hibernate.NewHibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Administrator
 */
public class SanPhamDAO {
    
    private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<SanPham> layDanhSach() {
        List<SanPham> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From SanPham where isDelete='0'").list();
        session.close();

        return list;
    }
    
    public List<SanPham> layDanhSachTheoLSP(String text) {
        List<SanPham> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From SanPham where isDelete='0' and LoaiSanPhamID='"+text+"'").list();
        session.close();

        return list;
    }
    
    public List<SanPham> layDanhSachTheoNCC(String text) {
        List<SanPham> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From SanPham where isDelete='0' and NhaCungCapID='"+text+"'").list();
        session.close();

        return list;
    }

    public SanPham find(String NhanVienID) {
        SanPham entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (SanPham) session.get(SanPham.class, NhanVienID);
        session.close();

        return entity;
    }

    public boolean delete(SanPham tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.delete(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean save(SanPham tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(SanPham tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.update(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }
    
}
