/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.Hdct;
import Entities.HoaDon;
import Hibernate.NewHibernateUtil;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Administrator
 */
public class HDCTDAO {

    private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<Hdct> layDanhSach() {
        List<Hdct> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From HDCT where isDelete='0'").list();
        session.close();

        return list;
    }

    public List<Hdct> layDanhSachDoanhThu() {
        List<Hdct> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createSQLQuery("Select distinct SanPhamID,TenSanPham,GiaBan, sum(SoLuong),sum(ThanhTien) From HDCT where YEAR(NgayTao)='2019' "
                + "group by SanPhamID,TenSanPham,GiaBan").list();
//        list = session.createQuery("distinct SanPhamID,TenSanPham,GiaBan, sum(SoLuong),sum(ThanhTien) From HDCT where YEAR(NgayTao)='2019' "
//                + "group by SanPhamID,TenSanPham,GiaBan").list();
        session.close();

        return list;
    }

    public Hdct find(String NhanVienID) {
        Hdct entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (Hdct) session.get(Hdct.class, NhanVienID);
        session.close();

        return entity;
    }

    public boolean save(Hdct tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        HoaDonDAO hdd = new HoaDonDAO();
        System.out.println(hdd.TaoHoaDonID());
//        System.out.println(hdd.layDanhSach());
    }

}
