/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.Hdct;
import Entities.HoaDon;
import Entities.LoaiSanPham;
import Hibernate.NewHibernateUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Administrator
 */
public class HoaDonDAO {

    private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<HoaDon> layDanhSach() {
        List<HoaDon> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From HoaDon where isDelete='0'").list();
        session.close();

        return list;
    }
    
    public List<HoaDon> layDanhSachDaXoa() {
        List<HoaDon> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From HoaDon where isDelete='1'").list();
        session.close();

        return list;
    }
     public List<Hdct> layDanhSachHdctTheoMaHD(String text) {
        List<Hdct> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From Hdct where hoaDonID='"+text+"'").list();
         System.out.println(list);
        session.close();

        return list;
    }
     
     public List<Hdct> layDanhSachHDCT() {
        List<Hdct> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From Hdct where HoaDonID in (From HoaDon where isDelete=0)").list();
        session.close();

        return list;
    }

    public HoaDon find(String NhanVienID) {
        HoaDon entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (HoaDon) session.get(HoaDon.class, NhanVienID);
        session.close();

        return entity;
    }

//    public boolean delete(HoaDon tk) {
//        Session session = NewHibernateUtil.getSessionFactory().openSession();
//        try {
//            session.beginTransaction();
//            session.delete(tk);
//            session.getTransaction().commit();
//            session.close();
//            return true;
//        } catch (Exception e) {
//            session.getTransaction().rollback();
//            session.close();
//            e.printStackTrace();
//            return false;
//        }
//    }
    public boolean save(HoaDon tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        HoaDonDAO hdd = new HoaDonDAO();
        System.out.println(hdd.TaoHoaDonID());
//        System.out.println(hdd.layDanhSach());
    }

    public String TaoHoaDonID() {
        String maHD = "";
        List<HoaDon> list;
        list = layDanhSach();
        if (list.size() < 0) {
            maHD = "HD1";
            System.out.println(maHD);
        } else {
            HoaDon hd = new HoaDon();
            Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            Criteria ctr = session.createCriteria(HoaDon.class);
//            ctr.add(Restrictions.like("isDelete",false));
            ctr.addOrder(Order.desc("ngayTao"));
            ctr.setMaxResults(1);
            List<HoaDon> hd1 = ctr.list();
            for (HoaDon hd2 : hd1) {
                maHD = hd2.getHoaDonId();
            }
            maHD = "HD"+String.valueOf(Integer.parseInt(maHD.substring(2, maHD.length())) + 1);
            session.close();
        }
        
        return maHD;
    }

    public boolean update(HoaDon tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.update(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }
}
