/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.*;
import Hibernate.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Administrator
 */
public class LoaiSanPhamDAO {

    private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<LoaiSanPham> layDanhSach() {
        List<LoaiSanPham> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From LoaiSanPham where isDelete='0'").list();
        session.close();

        return list;
    }
    

    public LoaiSanPham find(String NhanVienID) {
        LoaiSanPham entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (LoaiSanPham) session.get(LoaiSanPham.class, NhanVienID);
        session.close();

        return entity;
    }

//    public boolean delete(LoaiSanPham tk) {
//        Session session = NewHibernateUtil.getSessionFactory().openSession();
//        try {
//            session.beginTransaction();
//            session.delete(tk);
//            session.getTransaction().commit();
//            session.close();
//            return true;
//        } catch (Exception e) {
//            session.getTransaction().rollback();
//            session.close();
//            e.printStackTrace();
//            return false;
//        }
//    }
    public boolean save(LoaiSanPham tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(LoaiSanPham tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.update(tk);
            String hql = "UPDATE SanPham set isDelete = true WHERE LoaiSanPhamID = :id";
            Query query = session.createQuery(hql);
            query.setParameter("id", tk.getLoaiSanPhamId());
            int result = query.executeUpdate();
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

}
