/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.NhaCungCap;
import Hibernate.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Administrator
 */
public class NhaCungCapDAO {

    private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<NhaCungCap> layDanhSach() {
        List<NhaCungCap> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From NhaCungCap where isDelete='0'").list();
        session.close();

        return list;
    }

    public NhaCungCap find(String NhanVienID) {
        NhaCungCap entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (NhaCungCap) session.get(NhaCungCap.class, NhanVienID);
        session.close();

        return entity;
    }

    public boolean delete(NhaCungCap tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.delete(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean save(NhaCungCap tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(NhaCungCap tk) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.update(tk);
            String hql = "UPDATE SanPham set isDelete = true WHERE NhaCungCapID = :id";
            Query query = session.createQuery(hql);
            query.setParameter("id", tk.getNhaCungCapId());
            int result = query.executeUpdate();
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }
}
