/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Hibernate.NewHibernateUtil;
import Entities.NhanVien;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Administrator
 */
public class NhanVienDAO {

    private final SessionFactory sf = NewHibernateUtil.getSessionFactory();

    public List<NhanVien> layDanhSach() {
        List<NhanVien> list = null;

        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        list = session.createQuery("From NhanVien where isDelete='0'").list();
        session.close();

        return list;
    }

    public NhanVien find(String NhanVienID) {
        NhanVien entity = null;

        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        entity = (NhanVien) session.get(NhanVien.class, NhanVienID);
        session.close();

        return entity;
    }

    public boolean delete(NhanVien tk) {
        if (find(tk.getNhanVienId()) == null) {
            return false;
        }
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.delete(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean save(NhanVien tk) {
        if (find(tk.getNhanVienId()) != null) {
            return false;
        }
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.save(tk);
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(NhanVien tk) {
        if (find(tk.getNhanVienId()) == null) {
            return false;
        }
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        try {
            session.beginTransaction();
            session.update(tk);
             String hql = "UPDATE TaiKhoan set isDelete = true WHERE NhanVienID = :id";
            Query query = session.createQuery(hql);
            query.setParameter("id", tk.getNhanVienId());
            int result = query.executeUpdate();
            session.getTransaction().commit();
            session.close();
            return true;
        } catch (Exception e) {
            session.getTransaction().rollback();
            session.close();
            e.printStackTrace();
            return false;
        }
    }

}
