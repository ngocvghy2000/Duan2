/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Duan1;

import DAO.NhanVienDAO;
import Entities.NhanVien;
import helper.DateHelper;
import helper.DialogHelper;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author kiez5
 */
public class NhanSuJIF extends javax.swing.JInternalFrame {

    DefaultTableModel mdf = null;
    NhanVienDAO nvd = new NhanVienDAO();

    public NhanSuJIF() {
        initComponents();
        jPanel1.setFocusable(true);
        jPanel1.setSize(973, 779);
        this.setResizable(false);
        LoadData();
        LoadNam();
//        LoadCbbThang();

    }

    public void LoadNam() {
        jComboBox3.removeAllItems();
        int nam = 1920;
        for (int i = 0; i < 100; i++) {
            nam = nam + 1;
            jComboBox3.addItem(String.valueOf(nam));

        }
    }

    public void LoadCbbNgay() {
        if (jComboBox2.getSelectedItem().equals("4") || jComboBox2.getSelectedItem().equals("6") || jComboBox2.getSelectedItem().equals("9") || jComboBox2.getSelectedItem().equals("11")) {
            jComboBox1.removeAllItems();
            for (int i = 1; i < 31; i++) {
                jComboBox1.addItem(String.valueOf(i));
            }
        } else if (jComboBox2.getSelectedItem().equals("Tháng 2") && Integer.parseInt(jComboBox3.getSelectedItem().toString()) % 4 == 0) {
            jComboBox1.removeAllItems();
            for (int i = 1; i < 30; i++) {
                jComboBox1.addItem(String.valueOf(i));
            }
        } //             else if (jComboBox2.getSelectedItem().equals("Tháng 2") && Integer.parseInt(jComboBox3.getSelectedItem().toString()) % 4 == 0) {
        //                jComboBox1.removeAllItems();
        //            for (int i = 1; i < 30; i++) {
        //                jComboBox1.addItem(String.valueOf(i));
        //        }}
        else if (jComboBox2.getSelectedItem().equals("Tháng 2") && Integer.parseInt(jComboBox3.getSelectedItem().toString()) % 4 != 0) {
            jComboBox1.removeAllItems();
            for (int i = 1; i < 29; i++) {
                jComboBox1.addItem(String.valueOf(i));
            }
        } else {
            jComboBox1.removeAllItems();
            for (int i = 1; i < 32; i++) {
                jComboBox1.addItem(String.valueOf(i));
            }
        }
    }

//    public void LoadCbbThang() {
//        jComboBox2.removeAllItems();
//        for (int i = 1; i < 13; i++) {
//            jComboBox2.addItem(String.valueOf(i));
//        }
//    }
    private void LoadData() {
        mdf = (DefaultTableModel) tblNhanVien.getModel();
        mdf.setRowCount(0);
        for (NhanVien nv : this.nvd.layDanhSach()) {
            mdf.addRow(new Object[]{nv.getNhanVienId(),
                nv.getTenNhanVien(),
                nv.isGioiTinh() ? "Nam" : "Nữ",
                nv.getNgaySinh(),
                nv.getEmail(),
                nv.getSoDienThoai(),
                nv.getChucVu()});
        }

    }

    public boolean KiemTraNS() {
        String ma = txtMaNV.getText();
//        String ns = txtNgaySinh.getText();
        if (ma.equals("")) {
            DialogHelper.alert(this, "Chưa nhập mã nhân viên!");
            return false;
        } else if (!ma.startsWith("NV")) {
            DialogHelper.alert(this, "Mã phải bắt đầu bằng NV!");
            return false;
        } else if (txtHoVaTen.getText().equals("")) {
            DialogHelper.alert(this, "Chưa nhập tên nhân viên!");
            return false;
        } else if (2019 - Integer.parseInt(jComboBox3.getSelectedItem().toString()) < 18) {
            DialogHelper.alert(this, "Nhân viên chưa đủ 18 tuổi!");
            return false;
        } else if (!(txtEmail.getText()).matches("\\w+@\\w+\\.\\w+")) {
            DialogHelper.alert(this, "Email phải đúng định dạng!");
            return false;
        } else if (txtSDT.getText().equals("")) {
            DialogHelper.alert(this, "Chưa nhập số điện thoại");
            return false;
        } else if (!txtSDT.getText().startsWith("0")) {
            DialogHelper.alert(this, "Số điện thoại bắt đầu bằng số '0'!");
            return false;
        } else if (txtSDT.getText().length() != 10) {
            DialogHelper.alert(this, "Số điện thoại bao gồm 10 chữ số!");
            return false;
        }
        try {
            int sdt = Integer.valueOf(txtSDT.getText());
        } catch (Exception e) {
            DialogHelper.alert(this, "Số điện thoại phải nhập bằng số");
            return false;
        }

        return true;
    }

    public NhanVien layThongTinForm() {
        String check = txtMaNV.getText();
//        if(nvd.find(check));
        NhanVien nv = new NhanVien();
        nv.setNhanVienId(txtMaNV.getText());
        nv.setTenNhanVien(txtHoVaTen.getText());
        if (rbtNam.isSelected()) {
            nv.setGioiTinh(true);
        } else {
            nv.setGioiTinh(false);
        }
        String ngaySinh = jComboBox2.getSelectedItem().toString() + "/" + jComboBox1.getSelectedItem().toString() + "/" + jComboBox3.getSelectedItem().toString();
        nv.setNgaySinh(ngaySinh);
        nv.setEmail(txtEmail.getText());
        nv.setSoDienThoai(txtSDT.getText());
        nv.setChucVu(cbbChuVu.getSelectedItem().toString());
        return nv;
    }

    public void clear() {
        txtMaNV.setText("");
        txtHoVaTen.setText("");
        buttonGroup1.clearSelection();
        jComboBox1.setSelectedItem("1");
        jComboBox2.setSelectedItem("1");
        jComboBox3.setSelectedItem("2000");
        txtEmail.setText("");
        txtSDT.setText("");
        txtTimKiem.setText("");
    }

    public void update() {
        int i = tblNhanVien.getSelectedRow();
        String id = tblNhanVien.getValueAt(i, 0).toString();
        NhanVien nv = nvd.find(id);
        nv = layThongTinForm();
        boolean check = nvd.update(nv);
        if (check) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
            LoadData();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại!");
        }
    }

    public void delete() {
        int cf = JOptionPane.showConfirmDialog(null, "Bạn có muốn xoá?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (cf == JOptionPane.YES_OPTION) {
            int i = tblNhanVien.getSelectedRow();
            String id = tblNhanVien.getValueAt(i, 0).toString();
            NhanVien nv = nvd.find(id);
            nv.setIsDelete(true);
            boolean check = nvd.update(nv);
            if (check) {
                JOptionPane.showMessageDialog(this, "Xoá thành công!");
                LoadData();
            } else {
                JOptionPane.showMessageDialog(this, "Xoá thất bại!");
            }
        }
        clear();
    }

    public void mouserClick() {
        int i = tblNhanVien.getSelectedRow();
        txtMaNV.setText(tblNhanVien.getValueAt(i, 0).toString());
        txtHoVaTen.setText(tblNhanVien.getValueAt(i, 1).toString());
        String gt = tblNhanVien.getValueAt(i, 2).toString();
        if (gt.equalsIgnoreCase("nam")) {
            rbtNam.setSelected(true);
        } else {
            rbtNu.setSelected(true);
        }
        String ngaySinh = tblNhanVien.getValueAt(i, 3).toString();
        String nam = ngaySinh.substring(0, 4);
        jComboBox3.setSelectedItem(nam);
        String thang = ngaySinh.substring(5, 7);
        jComboBox2.setSelectedItem(thang);
        String ngay = ngaySinh.substring(8, 10);
        jComboBox1.setSelectedItem(ngay);
        txtEmail.setText(tblNhanVien.getValueAt(i, 4).toString());
        txtSDT.setText(tblNhanVien.getValueAt(i, 5).toString());
        cbbChuVu.setSelectedItem(tblNhanVien.getValueAt(i, 6).toString());
    }

    private void filter(String query) {
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(mdf);
        tblNhanVien.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(query));
    }

    private void save() {
        NhanVien nv = layThongTinForm();
        boolean save = nvd.save(nv);
        if (save) {
            JOptionPane.showMessageDialog(this, "Thêm thành công!");
            LoadData();
        } else {
            JOptionPane.showMessageDialog(this, "Mã nhân viên đã tồn tại!");
        }
        clear();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        btnFirst = new javax.swing.JButton();
        btnInsert = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtHoVaTen = new javax.swing.JTextField();
        txtMaNV = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        rbtNu = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblNhanVien = new javax.swing.JTable();
        rbtNam = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        btnLast = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnNext = new javax.swing.JButton();
        btnPrev = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cbbChuVu = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();

        setTitle("Quản Lý Nhân Sự");

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        btnFirst.setText("|<");

        btnInsert.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnInsert.setForeground(new java.awt.Color(255, 0, 0));
        btnInsert.setText("Thêm");
        btnInsert.setActionCommand("Thêm nhân viên");
        btnInsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertActionPerformed(evt);
            }
        });

        btnClear.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 0, 0));
        btnClear.setText("Xóa trắng ");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setText("Email");

        txtEmail.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setText("Ngày sinh");

        btnUpdate.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(255, 0, 0));
        btnUpdate.setText("Sửa");
        btnUpdate.setActionCommand("Sửa nhân viên");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("Số điện thoại");

        txtSDT.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 0));
        jLabel3.setText("Họ và tên");

        txtHoVaTen.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        txtMaNV.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("Mã nhân viên");

        btnDelete.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 0, 0));
        btnDelete.setText("Xóa ");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtNu);
        rbtNu.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        rbtNu.setForeground(new java.awt.Color(255, 0, 0));
        rbtNu.setText("Nữ");

        tblNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Họ tên", "Giới tính", "Ngày sinh", "Email", "Số điện thoại", "Chức vụ"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhanVien.setMaximumSize(new java.awt.Dimension(916, 259));
        tblNhanVien.setMinimumSize(new java.awt.Dimension(916, 259));
        tblNhanVien.setPreferredSize(new java.awt.Dimension(916, 259));
        tblNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhanVienMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblNhanVien);

        buttonGroup1.add(rbtNam);
        rbtNam.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        rbtNam.setForeground(new java.awt.Color(255, 0, 0));
        rbtNam.setSelected(true);
        rbtNam.setText("Nam");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("Giới tính");

        txtTimKiem.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        txtTimKiem.setForeground(new java.awt.Color(204, 204, 204));
        txtTimKiem.setText("Nhập mã nhân viên");
        txtTimKiem.setToolTipText("");
        txtTimKiem.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTimKiemFocusGained(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        btnLast.setText(">|");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("Quản lý nhân sự");

        btnNext.setText(">>");

        btnPrev.setText("<<");

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 0));
        jLabel8.setText("Tìm kiếm");

        cbbChuVu.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        cbbChuVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nhân Viên", "Quản Lý" }));

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 0, 0));
        jLabel9.setText("Chức vụ");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox3ItemStateChanged(evt);
            }
        });
        jComboBox3.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                jComboBox3HierarchyChanged(evt);
            }
        });
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });
        jComboBox3.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                jComboBox3VetoableChange(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        jComboBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox2ItemStateChanged(evt);
            }
        });
        jComboBox2.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                jComboBox2HierarchyChanged(evt);
            }
        });
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jComboBox2.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                jComboBox2VetoableChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 916, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnFirst)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnPrev)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnNext))
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addComponent(btnLast)))
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel7)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(rbtNam)
                                .addGap(40, 40, 40)
                                .addComponent(rbtNu, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtHoVaTen, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbbChuVu, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(60, 60, 60)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(47, 47, 47))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnInsert)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnUpdate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClear)
                        .addGap(94, 94, 94))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(387, 387, 387))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(363, 363, 363)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirst)
                    .addComponent(btnPrev)
                    .addComponent(btnNext)
                    .addComponent(btnLast))
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtHoVaTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbChuVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(rbtNam)
                    .addComponent(rbtNu))
                .addGap(38, 38, 38))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsert)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete)
                    .addComponent(btnClear))
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTimKiemFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiemFocusGained
        if (txtTimKiem.getText().trim().equals("Nhập mã nhân viên")) {
            txtTimKiem.setText("");
        }
    }//GEN-LAST:event_txtTimKiemFocusGained

    private void btnInsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertActionPerformed
        if (KiemTraNS()) {
            save();
        }
    }//GEN-LAST:event_btnInsertActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        if (KiemTraNS()) {
            delete();
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void tblNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhanVienMouseClicked
        mouserClick();
    }//GEN-LAST:event_tblNhanVienMouseClicked

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        String text = txtTimKiem.getText();
        filter(text);
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        clear();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        if (KiemTraNS()) {
            update();
            clear();
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void jComboBox3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox3ItemStateChanged
        LoadCbbNgay();
    }//GEN-LAST:event_jComboBox3ItemStateChanged

    private void jComboBox3HierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_jComboBox3HierarchyChanged

    }//GEN-LAST:event_jComboBox3HierarchyChanged

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed

    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jComboBox3VetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_jComboBox3VetoableChange

    }//GEN-LAST:event_jComboBox3VetoableChange

    private void jComboBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox2ItemStateChanged
        LoadCbbNgay();
    }//GEN-LAST:event_jComboBox2ItemStateChanged

    private void jComboBox2HierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_jComboBox2HierarchyChanged

    }//GEN-LAST:event_jComboBox2HierarchyChanged

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed

    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox2VetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_jComboBox2VetoableChange

    }//GEN-LAST:event_jComboBox2VetoableChange


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnInsert;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrev;
    private javax.swing.JButton btnUpdate;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbbChuVu;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbtNam;
    private javax.swing.JRadioButton rbtNu;
    private javax.swing.JTable tblNhanVien;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHoVaTen;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
