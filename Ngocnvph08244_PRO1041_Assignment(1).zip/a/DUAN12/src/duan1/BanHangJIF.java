/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Duan1;

import DAO.HDCTDAO;
import DAO.HoaDonDAO;
import DAO.NhanVienDAO;
import DAO.SanPhamDAO;
import Entities.Hdct;
import Entities.HoaDon;
import Entities.LoaiSanPham;
import Entities.NhaCungCap;
import Entities.SanPham;
import Entities.TaiKhoan;
import helper.CartBean;
import helper.DialogHelper;
import helper.FilterCombobox;
import helper.ProductDTO;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author kiez5
 */
public class BanHangJIF extends javax.swing.JInternalFrame {

    SanPhamDAO spd = new SanPhamDAO();
    NhanVienDAO nvd = new NhanVienDAO();
    HoaDonDAO hdd = new HoaDonDAO();
    HDCTDAO hdctd = new HDCTDAO();
    CartBean shop = new CartBean();
    FilterCombobox cbbsp = new FilterCombobox(populateArray());
    DefaultTableModel mdf = null;

    public BanHangJIF() {
        initComponents();
        jPanel1.setFocusable(true);
        jPanel1.setSize(973, 779);
        this.setResizable(false);
        lblTenNV.setText(helper.ShareHelper.USER.getChucVu()+ " : " + helper.ShareHelper.USER.getTenNhanVien());
        LoadCbb();

    }

    public void ThemGioHang() {
        SanPham sp = new SanPham();
        sp = spd.find(TachMa(cbbsp.getSelectedItem().toString()));
        ProductDTO sps = new ProductDTO(sp, Integer.parseInt(txtSoluong.getText()));
//        sps.setQuantity(Integer.parseInt());
        shop.addSanPham(sps);
        loadData();
        TongTien();
    }

    public void ThanhToan() {
        //Thêm vào Hoá Đơn//

        try {
            HoaDon hd = new HoaDon();
            hd.setNhanVien(helper.ShareHelper.USER);
            hd.setHoaDonId(hdd.TaoHoaDonID());
            hd.setIsDelete(false);
            hd.setThanhTien(LayTongTien());
            hd.setNgayTao(helper.DateHelper.convertDate());
            hdd.save(hd);

            int max = tblGioHang.getRowCount();

            //Thêm vào HDCT//
            for (int i = 0; i < max; i++) {
                SanPham sp = spd.find(tblGioHang.getValueAt(i, 0).toString());
                int soLuong = Integer.parseInt(tblGioHang.getValueAt(i, 4).toString());
                Hdct hdct = new Hdct();
                hdct.setHoaDon(hd);
                hdct.setNgayTao(hd.getNgayTao());
                hdct.setSanPham(sp);
                hdct.setSoLuong(soLuong);
                hdct.setTenSanPham(sp.getTenSanPham());
                hdct.setGiaBan(sp.getGiaBan());
                hdct.setThanhTien(sp.getGiaBan() * soLuong);
                hdctd.save(hdct);
                hdct.getHdctid();
            }
            helper.DialogHelper.alert(this, "Thanh toán thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            helper.DialogHelper.alert(this, "Thanh toán lỗi!");
        }

    }

    public boolean KiemTraBanHang() {
        
        if(txtSoluong.getText().isEmpty()){
            DialogHelper.alert(this, "Vui lòng nhập số lượng!");
            return false;
        }
        try {
            String soLuong = txtSoluong.getText();
            int bien = Integer.valueOf(soLuong);
        } catch (Exception e) {
            DialogHelper.alert(this, " Số lượng phải nhập bằng số");
            return false;
        }
        return true;
    }
    
    public void TongTien() {
        double tongTien = 0;

        int max = tblGioHang.getRowCount();
        for (int i = 0; i < max; i++) {
            double soLuong = Double.parseDouble(tblGioHang.getValueAt(i, 4).toString());
            double giaBan = Double.parseDouble(tblGioHang.getValueAt(i, 5).toString());
            tongTien = tongTien + (soLuong * giaBan);
        }
        lblTongTien.setText(String.valueOf(tongTien));
    }

    public float LayTongTien() {
        float tongTien = 0;

        int max = tblGioHang.getRowCount();
        for (int i = 0; i < max; i++) {
            float soLuong = Float.parseFloat(tblGioHang.getValueAt(i, 4).toString());
            float giaBan = Float.parseFloat(tblGioHang.getValueAt(i, 5).toString());
            tongTien = tongTien + (soLuong * giaBan);
        }
        return tongTien;
    }

    public void mouseClick() {
        int i = tblGioHang.getSelectedRow();
        if (i > -1 && i < tblGioHang.getRowCount()) {
            cbbsp.setSelectedItem(tblGioHang.getValueAt(i, 0).toString() + "-" + tblGioHang.getValueAt(i, 1).toString());
            txtSoluong.setText(tblGioHang.getValueAt(i, 4).toString());
        }
    }

    public int LaySoLuong() {
        int text = Integer.parseInt(txtSoluong.getText());
        return text;
    }

    public void loadData() {
        List<String> keys = new ArrayList<String>(shop.keySet());
        mdf = (DefaultTableModel) tblGioHang.getModel();
        mdf.setRowCount(0);
        for (String tk : keys) {
            ProductDTO sl = (ProductDTO) shop.get(tk);
            SanPham tk1 = spd.find(tk);
            mdf.addRow(new Object[]{tk1.getSanPhamId(), tk1.getTenSanPham(), tk1.getLoaiSanPham().getTenLoaiSanPham(), tk1.getDonViTinh(), sl.getQuantity(), tk1.getGiaBan()});
        }
//            shop.forEach((key,value)-> mdf.addRow(new Object[]{key,value}));
    }

    public void setRow() {
        mdf = (DefaultTableModel) tblGioHang.getModel();
        mdf.setRowCount(0);
        lblTongTien.setText("");
        txtSoluong.setText("");
    }

    public String TachMa(String chuoi) {
        String chuoi1 = chuoi.trim().substring(0, chuoi.trim().indexOf("-"));
        return chuoi1;
    }

    public static List<String> populateArray() {
        List<String> test = new ArrayList<String>();
        SanPhamDAO nvd = new SanPhamDAO();
        for (SanPham tk : nvd.layDanhSach()) {
            test.add(tk.getSanPhamId() + "-" + tk.getTenSanPham());
        }
        return test;
    }

    private void LoadCbb() {

        cbbsp.setVisible(true);
        cbbsp.setSize(280, 30);
        cbbsp.setLocation(40, 65);
        jPanel1.add(cbbsp);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtSoluong = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGioHang = new javax.swing.JTable();
        btnThanhToan = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnThemSP = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        lblTongTien = new javax.swing.JLabel();
        lblTenNV = new javax.swing.JLabel();

        jCheckBox1.setText("jCheckBox1");

        jLabel2.setText("jLabel2");

        setBackground(new java.awt.Color(204, 255, 204));
        setTitle("Quản lý bán hàng");
        setAutoscrolls(true);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        txtSoluong.setText("1");
        txtSoluong.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSoluongFocusGained(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 0));
        jLabel3.setText("Giỏ hàng");

        tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã sản phẩm", "Tên sản phẩm", "Loại sản phẩm", "Đơn vị tính", "Số lượng", "Giá bán"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblGioHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGioHangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGioHang);

        btnThanhToan.setBackground(new java.awt.Color(204, 255, 204));
        btnThanhToan.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnThanhToan.setForeground(new java.awt.Color(255, 0, 0));
        btnThanhToan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sanpham.png"))); // NOI18N
        btnThanhToan.setText("Thanh toán");
        btnThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhToanActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("Quản Lý Bán Hàng");

        btnThemSP.setText("Thêm vào giỏ");
        btnThemSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemSPActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("Tổng tiền của quý khác là: ");

        lblTongTien.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lblTongTien.setForeground(new java.awt.Color(255, 0, 0));

        lblTenNV.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lblTenNV.setForeground(new java.awt.Color(255, 51, 51));
        lblTenNV.setText("Long");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 468, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(434, 434, 434))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(345, 345, 345)
                        .addComponent(btnThemSP)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(txtSoluong, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(365, 365, 365)
                        .addComponent(jLabel1)))
                .addGap(89, 89, 89))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(lblTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnThanhToan)
                .addGap(71, 71, 71))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(btnThemSP))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(lblTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(14, 14, 14)
                .addComponent(txtSoluong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThanhToan)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTongTien))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtSoluongFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSoluongFocusGained
        if (txtSoluong.getText().trim().equals("Nhập số lượng")) {
            txtSoluong.setText("");
        }
    }//GEN-LAST:event_txtSoluongFocusGained

    private void btnThemSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemSPActionPerformed
        if(KiemTraBanHang()){
        ThemGioHang();
        }
        

    }//GEN-LAST:event_btnThemSPActionPerformed

    private void btnThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhToanActionPerformed
        if (tblGioHang.getRowCount() == 0) {
            helper.DialogHelper.alert(this, "Vui lòng thêm sản phẩm vào giỏ hàng.");
        } else {
            ThanhToan();
            setRow();
        }


    }//GEN-LAST:event_btnThanhToanActionPerformed

    private void tblGioHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGioHangMouseClicked
        mouseClick();
    }//GEN-LAST:event_tblGioHangMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JButton btnThemSP;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTenNV;
    private javax.swing.JLabel lblTongTien;
    private javax.swing.JTable tblGioHang;
    private javax.swing.JTextField txtSoluong;
    // End of variables declaration//GEN-END:variables
}
