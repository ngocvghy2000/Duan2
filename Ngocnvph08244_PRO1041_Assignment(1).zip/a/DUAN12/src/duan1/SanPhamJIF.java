/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Duan1;

import DAO.LoaiSanPhamDAO;
import DAO.NhaCungCapDAO;
import DAO.NhanVienDAO;
import DAO.SanPhamDAO;
import Entities.LoaiSanPham;
import Entities.NhaCungCap;
import Entities.SanPham;
import helper.DialogHelper;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author kiez5
 */
public class SanPhamJIF extends javax.swing.JInternalFrame {

    /**
     * Creates new form SanPham
     */
    public SanPhamJIF() {
        initComponents();
        jPanel1.setSize(973, 779);
        this.setResizable(false);
        jPanel1.setFocusable(true);
        jPanel2.setSize(973, 779);
        jPanel2.setFocusable(true);
        LoadData1();
        LoadData();
        LoadCbb();
    }

    DefaultTableModel mdf = null;
    NhanVienDAO nvd = new NhanVienDAO();
    LoaiSanPhamDAO lspd = new LoaiSanPhamDAO();
    SanPhamDAO spd = new SanPhamDAO();
    DefaultTableModel mdf1 = null;
    NhaCungCapDAO nccd = new NhaCungCapDAO();

    private void LoadData() {
        mdf = (DefaultTableModel) tblLoaiSanPham.getModel();
        mdf.setRowCount(0);
        for (LoaiSanPham nv : lspd.layDanhSach()) {
            mdf.addRow(new Object[]{nv.getLoaiSanPhamId(), nv.getTenLoaiSanPham()});
        }

    }

    public boolean KiemTraLoaiSanPham() {
        String malsp = txtMaLoaiSP.getText();
        if (malsp.equals("")) {
            DialogHelper.alert(this, "Chưa nhập mã loại sản phẩm!");
            return false;
        } else if (!malsp.startsWith("LSP")) {
            DialogHelper.alert(this, "Mã bắt đầu bằng LSP!");
            return false;
        } else if (txtTenLoaiSP.getText().equals("")) {
            DialogHelper.alert(this, "Chưa nhập tên loại sản phẩm!");
            return false;
        }
        return true;
    }

    public boolean KiemTraSanPham() {
        String malsp = txtMaSP.getText();
        if (malsp.equals("")) {
            DialogHelper.alert(this, "Chưa nhập mã Sản phẩm!");
            return false;
        } else if (!malsp.startsWith("SP")) {
            DialogHelper.alert(this, "Mã bắt đầu bằng 'SP'!");
            return false;
        } else if (txtTenSP.getText().equals("")) {
            DialogHelper.alert(this, "Chưa nhập tên Sản phẩm!");
            return false;
        }
        try {
            int giaBan = Integer.valueOf(txtGiaBan.getText());
            if (giaBan < 0) {
                DialogHelper.alert(this, "Giá bán được nhập là số nguyên dương!");
                return false;
            }
        } catch (Exception e) {
            DialogHelper.alert(this, "Giá bán được nhập là số nguyên!");
            return false;
        }
        try {
            int giaNhap = Integer.valueOf(txtGiaBan.getText());
            if (giaNhap < 0) {
                DialogHelper.alert(this, "Giá nhập được nhập là số nguyên dương!");
                return false;
            }
        } catch (Exception e) {
            DialogHelper.alert(this, "Giá nhập được nhập là số nguyên!");
            return false;
        }
        return true;
    }

    public LoaiSanPham layThongTinForm() {
        LoaiSanPham nv = new LoaiSanPham();
        LoaiSanPham sp = lspd.find(txtMaLoaiSP.getText());
        nv.setLoaiSanPhamId(txtMaLoaiSP.getText());
        nv.setTenLoaiSanPham(txtTenLoaiSP.getText());
        nv.setIsDelete(false);
        return nv;
    }

    public void layDanhSachTheoLSP() {
        mdf1 = (DefaultTableModel) tblSanPham.getModel();
        mdf1.setRowCount(0);
        List<SanPham> list = spd.layDanhSachTheoLSP(TachMa(cbbLoaiSanPham.getSelectedItem().toString()));
        if (list.size() == 0) {
            helper.DialogHelper.alert(this, "Không tìm thấy Sản phẩm thuộc Loại sản phẩm này!");
            LoadData1();
        }
        for (SanPham nv : list) {
            mdf1.addRow(new Object[]{nv.getSanPhamId(),
                nv.getTenSanPham(),
                nv.getLoaiSanPham().getLoaiSanPhamId(),
                nv.getNhaCungCap().getNhaCungCapId(),
                nv.getDonViTinh(), nv.getGiaNhap(),
                nv.getGiaBan()});
        }

    }

    public void layDanhSachTheoNCC() {
        mdf1 = (DefaultTableModel) tblSanPham.getModel();
        mdf1.setRowCount(0);
        List<SanPham> list = spd.layDanhSachTheoNCC(TachMa(cbbNhaCungCap.getSelectedItem().toString()));
        if (list.size() == 0) {
            helper.DialogHelper.alert(this, "Không tìm thấy Sản phẩm được cung cấp bởi Nhà cung cấp này!");
            LoadData1();
        }
        for (SanPham nv : list) {
            mdf1.addRow(new Object[]{nv.getSanPhamId(),
                nv.getTenSanPham(),
                nv.getLoaiSanPham().getLoaiSanPhamId(),
                nv.getNhaCungCap().getNhaCungCapId(),
                nv.getDonViTinh(), nv.getGiaNhap(),
                nv.getGiaBan()});
        }

    }

    public void clear() {
        txtMaLoaiSP.setText("");
        txtTenLoaiSP.setText("");
        txtTimKiem.setText("");
    }

    public void update() {
        int i = tblLoaiSanPham.getSelectedRow();
        String id = tblLoaiSanPham.getValueAt(i, 0).toString();
        LoaiSanPham nv = lspd.find(id);
        nv = layThongTinForm();
        boolean check = lspd.update(nv);
        if (check) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
            LoadData();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại!");
        }
        clear();
    }

    public void mouserClick() {
        int i = tblLoaiSanPham.getSelectedRow();
        if (i < tblLoaiSanPham.getRowCount()) {
            txtMaLoaiSP.setText(tblLoaiSanPham.getValueAt(i, 0).toString());
            txtTenLoaiSP.setText(tblLoaiSanPham.getValueAt(i, 1).toString());
        }
    }

    private void filter(String query) {
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(mdf);
        tblLoaiSanPham.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(query));
    }

    private void ThemTaiKhoan() {
        LoaiSanPham nv = layThongTinForm();
        boolean save = lspd.save(nv);
        if (save) {
            JOptionPane.showMessageDialog(this, "Thêm thành công!");
            LoadData();

        } else {
            JOptionPane.showMessageDialog(this, "Mã loại sản phẩm đã tồn tại!");
        }
        clear();
    }

    private void XoaTaiKhoan() {
        int cf = JOptionPane.showConfirmDialog(null, "Bạn có muốn xoá?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (cf == JOptionPane.YES_OPTION) {
            int i = tblLoaiSanPham.getSelectedRow();
            String id = tblLoaiSanPham.getValueAt(i, 0).toString();
            LoaiSanPham nv = lspd.find(id);
            nv.setIsDelete(true);
            boolean check = lspd.update(nv);
            if (check) {
                JOptionPane.showMessageDialog(this, "Xoá thành công!");
                LoadData();
                LoadData1();
            } else {
                JOptionPane.showMessageDialog(this, "Xoá thất bại!");
            }
            clear();
        }
    }

    ///SAN PHAM///
    private void LoadData1() {
        mdf1 = (DefaultTableModel) tblSanPham.getModel();
        mdf1.setRowCount(0);
        for (SanPham nv : spd.layDanhSach()) {
            mdf1.addRow(new Object[]{nv.getSanPhamId(),
                nv.getTenSanPham(),
                nv.getLoaiSanPham().getLoaiSanPhamId(),
                nv.getNhaCungCap().getNhaCungCapId(),
                nv.getDonViTinh(), nv.getGiaNhap(),
                nv.getGiaBan()});
        }

    }

    private void LoadCbb() {
        cbbLoaiSanPham.removeAllItems();
        cbbNhaCungCap.removeAllItems();
        for (LoaiSanPham tk : this.lspd.layDanhSach()) {
            cbbLoaiSanPham.addItem(tk.getLoaiSanPhamId() + "-" + tk.getTenLoaiSanPham());
        }
        for (NhaCungCap tk1 : this.nccd.layDanhSach()) {
            cbbNhaCungCap.addItem(tk1.getNhaCungCapId() + "-" + tk1.getTenNhaCungCap());
        }
    }

    public SanPham layThongTinForm1() {
        SanPham nv = new SanPham();
        nv.setSanPhamId(txtMaSP.getText());
        nv.setTenSanPham(txtTenSP.getText());
        nv.setLoaiSanPham(lspd.find(TachMa(cbbLoaiSanPham.getSelectedItem().toString())));
        nv.setNhaCungCap(nccd.find(TachMa(cbbNhaCungCap.getSelectedItem().toString())));
        nv.setGiaBan(Float.parseFloat(txtGiaBan.getText()));
        nv.setGiaNhap(Float.parseFloat(txtGiaNhap.getText()));
        nv.setDonViTinh(cbxDonViTinh.getSelectedItem().toString());
        nv.setIsDelete(false);
        return nv;
    }

    public String TachMa(String chuoi) {
        String chuoi1 = chuoi.trim().substring(0, chuoi.trim().indexOf("-"));
        return chuoi1;
    }

    public void clear1() {
        txtGiaBan.setText("");
        txtGiaNhap.setText("");
        txtMaSP.setText("");
        txtMaLoaiSP.setText("");
        txtTenLoaiSP.setText("");
        txtTenSP.setText("");
        cbbLoaiSanPham.setSelectedIndex(0);
        cbbNhaCungCap.setSelectedIndex(0);
        cbxDonViTinh.setSelectedIndex(0);
    }

    public void update1() {
        int i = tblSanPham.getSelectedRow();
        String id = tblSanPham.getValueAt(i, 0).toString();
        SanPham nv = spd.find(id);
        nv = layThongTinForm1();
        boolean check = spd.update(nv);
        if (check) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
            LoadData1();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại!");
        }
        clear1();
    }

    public void mouserClick1() {
        int i = tblSanPham.getSelectedRow();
        if (i < tblSanPham.getRowCount()) {
            txtMaSP.setText(tblSanPham.getValueAt(i, 0).toString());
            txtTenSP.setText(tblSanPham.getValueAt(i, 1).toString());
            cbbLoaiSanPham.setSelectedItem(tblSanPham.getValueAt(i, 2).toString() + "-" + lspd.find(tblSanPham.getValueAt(i, 2).toString()).getTenLoaiSanPham());
            txtGiaBan.setText(tblSanPham.getValueAt(i, 6).toString().replace(".0", ""));
            cbbNhaCungCap.setSelectedItem(tblSanPham.getValueAt(i, 3).toString() + "-" + nccd.find(tblSanPham.getValueAt(i, 3).toString()).getTenNhaCungCap());
            cbxDonViTinh.setSelectedItem(tblSanPham.getValueAt(i, 4));
            txtGiaNhap.setText(tblSanPham.getValueAt(i, 5).toString().replace(".0", ""));
        }
    }

    private void filter1(String query) {
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(mdf1);
        tblSanPham.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(query));
    }

    private void ThemTaiKhoan1() {
        SanPham nv = layThongTinForm1();
        boolean save = spd.save(nv);
        if (save) {
            JOptionPane.showMessageDialog(this, "Thêm thành công!");
            LoadData1();

        } else {
            JOptionPane.showMessageDialog(this, "Thêm thất bại!");
        }
        clear1();
    }

    private void XoaTaiKhoan1() {
        int cf = JOptionPane.showConfirmDialog(null, "Bạn có muốn xoá?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (cf == JOptionPane.YES_OPTION) {
            int i = tblSanPham.getSelectedRow();
            String id = tblSanPham.getValueAt(i, 0).toString();
            SanPham nv = spd.find(id);
            nv.setIsDelete(true);
            boolean check = spd.update(nv);
            if (check) {
                JOptionPane.showMessageDialog(this, "Xoá thành công!");
                LoadData1();
            } else {
                JOptionPane.showMessageDialog(this, "Xoá thất bại!");
            }
            clear1();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnInsert = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnFirst = new javax.swing.JButton();
        txtMaSP = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtGiaNhap = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtGiaBan = new javax.swing.JTextField();
        cbxDonViTinh = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        btnPrev = new javax.swing.JButton();
        txtTenSP = new javax.swing.JTextField();
        btnNext = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnLast = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbbNhaCungCap = new javax.swing.JComboBox<>();
        cbbLoaiSanPham = new javax.swing.JComboBox<>();
        btnTimLSP = new javax.swing.JButton();
        btnTimNCC = new javax.swing.JButton();
        btnTaiSanPham = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnLast1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtMaLoaiSP = new javax.swing.JTextField();
        txtTenLoaiSP = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblLoaiSanPham = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        btnFirst1 = new javax.swing.JButton();
        btnPrev1 = new javax.swing.JButton();
        btnNext1 = new javax.swing.JButton();
        btnInsert1 = new javax.swing.JButton();
        btnUpdate1 = new javax.swing.JButton();
        btnDelete1 = new javax.swing.JButton();
        btnClear1 = new javax.swing.JButton();
        txtTimKiem1 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();

        setTitle("Quản Lý Sản Phẩm");

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setForeground(new java.awt.Color(255, 0, 0));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("Quản Lý Sản Phẩm");

        btnInsert.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnInsert.setForeground(new java.awt.Color(255, 0, 0));
        btnInsert.setText("Thêm");
        btnInsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertActionPerformed(evt);
            }
        });

        btnUpdate.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(255, 0, 0));
        btnUpdate.setText("Sửa ");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã sản phẩm", "Tên sản phẩm", "Mã loại sản phẩm", "Mã nhà cung cấp", "Đơn vị tính", "Giá nhập", "Giá bán"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSanPham.setMaximumSize(new java.awt.Dimension(916, 259));
        tblSanPham.setMinimumSize(new java.awt.Dimension(916, 259));
        tblSanPham.setPreferredSize(new java.awt.Dimension(916, 259));
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSanPham);

        btnDelete.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 0, 0));
        btnDelete.setText("Xóa");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnClear.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 0, 0));
        btnClear.setText("Xóa trắng ");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("Mã sản phẩm");

        btnFirst.setText("|<");

        txtMaSP.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setText("Mã nhà cung cấp");

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 0));
        jLabel8.setText("Giá nhập");

        txtGiaNhap.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 0, 0));
        jLabel9.setText("Giá bán");

        txtGiaBan.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        cbxDonViTinh.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        cbxDonViTinh.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gói", "Kg", "Cái", "Hộp", "Chai", "Lô", "Lon", "Thùng", "Quyển" }));

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 0));
        jLabel10.setText("Đơn vị tính");

        txtTimKiem.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        txtTimKiem.setForeground(new java.awt.Color(153, 153, 153));
        txtTimKiem.setText("Nhập mã sản phẩm");
        txtTimKiem.setToolTipText("");
        txtTimKiem.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTimKiemFocusGained(evt);
            }
        });
        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        btnPrev.setText("<<");

        txtTenSP.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        btnNext.setText(">>");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 0));
        jLabel3.setText("Tên sản phẩm");

        btnLast.setText(">|");

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("Mã loại sản phẩm");

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setText("Tìm kiếm");

        cbbNhaCungCap.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        cbbNhaCungCap.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbbLoaiSanPham.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        cbbLoaiSanPham.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbLoaiSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbLoaiSanPhamActionPerformed(evt);
            }
        });

        btnTimLSP.setText("Tìm");
        btnTimLSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimLSPActionPerformed(evt);
            }
        });

        btnTimNCC.setText("Tìm");
        btnTimNCC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimNCCActionPerformed(evt);
            }
        });

        btnTaiSanPham.setText("Tải dữ liệu sản phẩm");
        btnTaiSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTaiSanPhamActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel9))
                                .addGap(38, 38, 38)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtGiaBan, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbbLoaiSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnTaiSanPham))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnTimLSP)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(37, 37, 37)
                                                .addComponent(btnInsert)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(btnUpdate)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnDelete)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnClear))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel10)
                                                    .addComponent(jLabel6)
                                                    .addComponent(jLabel8))
                                                .addGap(55, 55, 55)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtGiaNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                            .addComponent(cbxDonViTinh, 0, 205, Short.MAX_VALUE)
                                                            .addComponent(cbbNhaCungCap, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(btnTimNCC)))))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnFirst)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnPrev)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnNext)
                                        .addGap(13, 13, 13)
                                        .addComponent(btnLast)
                                        .addGap(90, 90, 90))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 972, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(15, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(366, 366, 366)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cbbLoaiSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTimLSP))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtGiaBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cbbNhaCungCap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnTimNCC)
                                    .addComponent(jLabel6))
                                .addGap(23, 23, 23)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cbxDonViTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(txtGiaNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnTaiSanPham)
                                .addComponent(btnFirst)
                                .addComponent(btnPrev)
                                .addComponent(btnNext)
                                .addComponent(btnLast)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsert)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete)
                    .addComponent(btnClear))
                .addGap(74, 74, 74))
        );

        jTabbedPane1.addTab("Quản Lý Sản Phẩm", jPanel1);

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));

        btnLast1.setText(">|");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("Mã loại sản phẩm");

        txtMaLoaiSP.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N

        txtTenLoaiSP.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 0));
        jLabel11.setText("Tênl oại sản phẩm");

        tblLoaiSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã loại sản phẩm", "Tên Loại sản phẩm"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblLoaiSanPham.setMaximumSize(new java.awt.Dimension(916, 259));
        tblLoaiSanPham.setMinimumSize(new java.awt.Dimension(916, 259));
        tblLoaiSanPham.setPreferredSize(new java.awt.Dimension(916, 259));
        tblLoaiSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLoaiSanPhamMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblLoaiSanPham);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 0, 0));
        jLabel13.setText("Quản Lý Loại Sản Phẩm");

        btnFirst1.setText("|<");

        btnPrev1.setText("<<");

        btnNext1.setText(">>");

        btnInsert1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnInsert1.setForeground(new java.awt.Color(255, 0, 0));
        btnInsert1.setText("Thêm");
        btnInsert1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsert1ActionPerformed(evt);
            }
        });

        btnUpdate1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnUpdate1.setForeground(new java.awt.Color(255, 0, 0));
        btnUpdate1.setText("Sửa ");
        btnUpdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate1ActionPerformed(evt);
            }
        });

        btnDelete1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnDelete1.setForeground(new java.awt.Color(255, 0, 0));
        btnDelete1.setText("Xóa");
        btnDelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete1ActionPerformed(evt);
            }
        });

        btnClear1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnClear1.setForeground(new java.awt.Color(255, 0, 0));
        btnClear1.setText("Xóa trắng ");
        btnClear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClear1ActionPerformed(evt);
            }
        });

        txtTimKiem1.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        txtTimKiem1.setForeground(new java.awt.Color(153, 153, 153));
        txtTimKiem1.setText("Nhập mã loại sản phẩm");
        txtTimKiem1.setToolTipText("");
        txtTimKiem1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTimKiem1FocusGained(evt);
            }
        });
        txtTimKiem1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiem1KeyReleased(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 0, 0));
        jLabel14.setText("Tìm kiếm");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(338, 338, 338)
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(56, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTimKiem1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnFirst1)
                        .addGap(18, 18, 18)
                        .addComponent(btnPrev1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNext1)
                        .addGap(13, 13, 13)
                        .addComponent(btnLast1))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 898, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(56, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(165, 165, 165)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtMaLoaiSP)
                        .addComponent(txtTenLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel11))
                        .addGap(336, 336, 336)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnInsert1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnUpdate1)
                .addGap(18, 18, 18)
                .addComponent(btnDelete1)
                .addGap(18, 18, 18)
                .addComponent(btnClear1)
                .addGap(107, 107, 107))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirst1)
                    .addComponent(btnPrev1)
                    .addComponent(btnNext1)
                    .addComponent(btnLast1))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtMaLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTenLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(52, 52, 52)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsert1)
                    .addComponent(btnUpdate1)
                    .addComponent(btnDelete1)
                    .addComponent(btnClear1))
                .addContainerGap(114, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Quản Lý Loại Sản Phẩm", jPanel2);

        getContentPane().add(jTabbedPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTimKiemFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiemFocusGained
        if (txtTimKiem.getText().trim().equals("Nhập mã sản phẩm")) {
            txtTimKiem.setText("");
        }
    }//GEN-LAST:event_txtTimKiemFocusGained

    private void txtTimKiem1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiem1FocusGained
        if (txtTimKiem1.getText().trim().equals("Nhập mã loại sản phẩm")) {
            txtTimKiem1.setText("");
        }
    }//GEN-LAST:event_txtTimKiem1FocusGained

    private void txtTimKiem1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiem1KeyReleased
        String text = txtTimKiem1.getText();
        filter(text);
    }//GEN-LAST:event_txtTimKiem1KeyReleased

    private void tblLoaiSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLoaiSanPhamMouseClicked
        mouserClick();
    }//GEN-LAST:event_tblLoaiSanPhamMouseClicked

    private void btnInsert1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsert1ActionPerformed
        if (KiemTraLoaiSanPham()) {
            ThemTaiKhoan();
        }
    }//GEN-LAST:event_btnInsert1ActionPerformed

    private void btnUpdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate1ActionPerformed
        if (KiemTraLoaiSanPham()) {
            update();
        }
    }//GEN-LAST:event_btnUpdate1ActionPerformed

    private void btnDelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete1ActionPerformed
        if (KiemTraLoaiSanPham()) {
            XoaTaiKhoan();
        }
    }//GEN-LAST:event_btnDelete1ActionPerformed

    private void btnClear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClear1ActionPerformed
        clear();
    }//GEN-LAST:event_btnClear1ActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        clear1();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnInsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertActionPerformed
        if (KiemTraSanPham()) {
            ThemTaiKhoan1();
        }
    }//GEN-LAST:event_btnInsertActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        if (KiemTraSanPham()) {
            update1();
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        if (KiemTraSanPham()) {
            XoaTaiKhoan1();
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        String text = txtTimKiem.getText();
        filter1(text);
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        mouserClick1();
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void btnTimLSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimLSPActionPerformed
        layDanhSachTheoLSP();
    }//GEN-LAST:event_btnTimLSPActionPerformed

    private void btnTimNCCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimNCCActionPerformed
        layDanhSachTheoNCC();
    }//GEN-LAST:event_btnTimNCCActionPerformed

    private void cbbLoaiSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbLoaiSanPhamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbLoaiSanPhamActionPerformed

    private void btnTaiSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTaiSanPhamActionPerformed
        LoadData1();
    }//GEN-LAST:event_btnTaiSanPhamActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnClear1;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDelete1;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnFirst1;
    private javax.swing.JButton btnInsert;
    private javax.swing.JButton btnInsert1;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnLast1;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnNext1;
    private javax.swing.JButton btnPrev;
    private javax.swing.JButton btnPrev1;
    private javax.swing.JButton btnTaiSanPham;
    private javax.swing.JButton btnTimLSP;
    private javax.swing.JButton btnTimNCC;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUpdate1;
    private javax.swing.JComboBox<String> cbbLoaiSanPham;
    private javax.swing.JComboBox<String> cbbNhaCungCap;
    private javax.swing.JComboBox<String> cbxDonViTinh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tblLoaiSanPham;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtGiaBan;
    private javax.swing.JTextField txtGiaNhap;
    private javax.swing.JTextField txtMaLoaiSP;
    private javax.swing.JTextField txtMaSP;
    private javax.swing.JTextField txtTenLoaiSP;
    private javax.swing.JTextField txtTenSP;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtTimKiem1;
    // End of variables declaration//GEN-END:variables
}
