/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helper;

import Entities.NhanVien;
import Entities.TaiKhoan;

/**
 *
 * @author Administrator
 */
public class ShareHelper {

    public static NhanVien USER = null;
    public static TaiKhoan TK = null;
    public static String ChucVu = null;
    public static void logoff() {
        ShareHelper.USER = null;
    }
    
    public static boolean authenticated() {
        return ShareHelper.USER != null;
    }

}
