/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helper;

import Duan1.BanHangJIF;
import Entities.SanPham;
import java.util.HashMap;

/**
 *
 * @author Tu Ech
 */
public class CartBean extends HashMap {

    public void addSanPham(ProductDTO sp) {
        BanHangJIF bh = new BanHangJIF();
        String key = sp.getSanpham().getSanPhamId();
//        if (this.containsKey(key)) {
////            int oldQuantity = ((ProductDTO) this.get(key)).getQuantity();
//            ((ProductDTO) this.get(key)).setQuantity(bh.LaySoLuong());
//            ProductDTO por  = (ProductDTO)this.get(key);
//            System.out.println("Day la so luong pro"+por.getQuantity());
//        } else {
            this.put(sp.getSanpham().getSanPhamId(), sp);
        
    }

    public boolean removeSanPham(SanPham code) {
        if (this.containsKey(code)) {
            this.remove(code);
            return true;
        }
        return false;
    }

    public CartBean() {
        super();
    }
}
