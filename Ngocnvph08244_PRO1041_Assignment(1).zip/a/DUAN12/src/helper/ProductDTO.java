/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helper;

import Entities.SanPham;
import java.io.Serializable;

/**
 *
 * @author Tu Ech
 */
public class ProductDTO implements Serializable{
    private SanPham sanpham;
    private int quantity;
    public ProductDTO() {
    }
    public ProductDTO(SanPham sp, int soLuong) {
        this.sanpham = sp;
        this.quantity = soLuong;
    }
    public SanPham getSanpham() {
        return sanpham;
    }
    public void setSanpham(SanPham sanpham) {
        this.sanpham = sanpham;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }   
}
